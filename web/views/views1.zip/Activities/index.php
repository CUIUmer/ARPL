<?php if (isset($_SESSION['is_logged_in'])) : ?>
<div class="col-sm-12">
    <div class="card">
        <div class="card-header">
            <strong class="card-title">Activity List</strong>
        </div>
        <div class="card-body">

        </div>
    </div>
</div>
<?php endif; ?>
<?php if (!isset($_SESSION['is_logged_in'])) : ?>
    <script>
        $url = "<?php echo ROOT_URL; ?>";
        location.replace($url + 'users/login');
    </script>
<?php endif; ?>