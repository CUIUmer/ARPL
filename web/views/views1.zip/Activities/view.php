<?php if (isset($_SESSION['is_logged_in'])) : ?>
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <strong class="card-title">Activity List</strong>
            </div>
            <div class="card-body">
                <!--                    ADMIN-->
                <?php $activity = new ActivityModel();
                $viewmodel = $activity->loadActivity();
                $n = sizeof($viewmodel)-1;
                ?>
                <?php $dt = new DateTime($viewmodel[$n]['creation_date']); ?>
                <h3><?php echo $viewmodel[$n]['project_name']; ?></h3>
                <p><?php echo $viewmodel[$n]['description']; ?></p>
                <p>Creation Date: <?php echo($dt->format('d/M/Y-D')); ?></p>
                <!--                            <p><a href="-->
                <?php //echo ROOT_URL . $item['f']; ?><!--">Open</a></p>-->
                <?php echo '<hr/>'; ?>

                <?php
                if (isset($viewmodel[$n])) { ?>
                    <form class="form-horizontal" method="post" action="<?php $_SERVER['PHP_SELF']; ?>"
                          enctype="multipart/form-data">
                        <div class="card-body card-block">
                            <div class="row form-group">
                                <label>Description</label>
                                <textarea name="description" class="form-control" rows="10"
                                          cols=59><?php if (isset($viewmodel[$n]) && $n!=0) {
                                        echo($viewmodel[0]['description']);} ?>
                            </textarea>
                                <!--                            <input type="text" name="description" class="form-control"/>-->
                            </div>
                            <div class="row form-group">
                                <label>File: (Allowed Files: Doc, pdf, txt, jpg, jpeg, gif, png)</label>
<!--                                <input type="file" name="file_array[]" class="form-control"/>-->
<!--                                <input type="file" name="file_array[]" class="form-control"/>-->
<!--                                <input type="file" name="file_array[]" class="form-control"/>-->
                                <input type="file" name="file[]" multiple="" class="form-control"/>
                            </div>
                            <input class="btn btn-primary" name="submit" type="submit" value="Submit"/>
                        </div>
                    </form>
                <?php } ?>

                <!--                    Else-->

                <?php
                if (isset($viewmodel[0]) && $n!=0) {
                    echo '<hr/>';
                    for ($i = 0; $i < $n; $i++) {
                        ?>
                        <?php $dt = new DateTime($viewmodel[$i]['creation_date']); ?>
                        <h4><?php echo ($i+1); ?></h4>
                        <textarea class="form-control" rows="10"
                                  cols=59><?php echo $viewmodel[$i]['description']; ?></textarea>
                        <p>Editing Date: <?php echo($dt->format('d/M/Y-D')); ?></p>
                        <!--                        <p><a href="--><?php //echo ROOT_URL . $item['f']; ?><!--">Open</a></p>-->
                        <div class="ti-image">
                            <h5>Files: </h5>
                            <?php
                            $images = $activity->loadImages($viewmodel[$i]['description']);
                            foreach ($images as $image){ ?>
                            <a target="_blank" href="<?php echo ROOT_URL.$image['file'] ?>">
                                <img src="<?php echo ROOT_URL.$image['file'] ?>" width="150px" height="150px">
                            </a>
                            <?php } ?>
                        </div>
                    <br>
                    <br>
                    <?php }
                } else { ?>
                    <h3>No Activity to Display</h3>
                <?php } ?>

            </div>
        </div>
    </div>
<?php endif; ?>
<?php if (!isset($_SESSION['is_logged_in'])) : ?>
    <script>
        $url = "<?php echo ROOT_URL; ?>";
        location.replace($url + 'users/login');
    </script>
<?php endif; ?>