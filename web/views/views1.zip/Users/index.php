<?php if (isset($_SESSION['is_logged_in'])) : ?>
<?php if ($_SESSION['user_data']['region'] == 'ISLAMABAD') : ?>
<div class="col-sm-12">
    <div class="card">
        <div class="card-header">
            <strong class="card-title">User List</strong>
        </div>
        <div class="card-body">
            <table id="bootstrap-data-table" class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Region</th>
                    <th>Register Date</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($viewmodel as $item) : ?>
                    <?php $dt = new DateTime($item['register_date']); ?>
                    <tr>
                        <td><?php echo $item['name']; ?></td>
                        <td><?php echo $item['email']; ?></td>
                        <td><?php echo $item['region']; ?></td>
                        <td><?php echo ($dt->format('d/M/Y-D')); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
    <?php endif; ?>
<?php endif; ?>
<?php if (!isset($_SESSION['is_logged_in'])) : ?>
    <script>
        $url = "<?php echo ROOT_URL; ?>";
        location.replace($url+'users/login');
    </script>
<?php endif; ?>