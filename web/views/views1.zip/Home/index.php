<div class="col-sm-5" style="margin-left: auto; margin-right: auto; width: 50%">
    <div class="card">
        <div class="card-header">
            <strong>Welcome</strong>
        </div>
        <div class="card-body">
            <?php if (isset($_SESSION['is_logged_in'])) : ?>
                <a class="btn btn-primary btn-sm"
                   href="<?php echo ROOT_URL; ?>">Welcome <?php echo $_SESSION['user_data']['name']; ?></a>
                <a class="btn btn-primary btn-sm" href="<?php echo ROOT_URL; ?>users/logout">Logout</a>
            <?php else : ?>
                <a class="btn btn-primary btn-block" href="<?php echo ROOT_URL; ?>users/login">Login</a>
                <a class="btn btn-primary btn-block" href="<?php echo ROOT_URL; ?>users/register">Register</a>
            <?php endif; ?>
        </div>
    </div>
</div>