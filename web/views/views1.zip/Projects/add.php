<?php if (isset($_SESSION['is_logged_in'])) : ?>
    <?php if ($_SESSION['user_data']['region'] == 'ISLAMABAD') : ?>
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <strong>Add Project Details Here</strong>
            </div>
            <div class="card-body">
                <!--            <div class="panel-body">-->
                <form class="form-horizontal" method="post" action="<?php $_SERVER['PHP_SELF']; ?>">
                    <div class="card-body card-block">
                        <div class="row form-group">
                            <label>Name</label>
                            <input type="text" name="name" class="form-control"/>
                        </div>
                        <div class="row form-group">
                            <label>Description</label>
                            <input type="text" name="description" class="form-control"/>
                        </div>
                        <div class="row form-group">
                            <label>Start Date</label>
                            <input type="date" name="start" class="form-control"/>
                        </div>
                        <div class="row form-group">
                            <label>End Date</label>
                            <input type="date" name="end" class="form-control"/>
                        </div>
                        <div class="row form-group">
                            <label>Region</label>
                            <select name="region" class="form-control">
                                <?php
                                $region = new RegionModel();
                                $regions = $region->loadRegion();
                                foreach ($regions as $item) {
                                    echo "<option value='" . $item['region'] . "'>" . $item['region'] . "</option>";
                                } ?>
                            </select>
                        </div>
                        <input class="btn btn-primary" name="submit" type="submit" value="Submit"/>
                    </div>
                </form>
                <!--            </div>-->
            </div>
        </div>
    </div>
<?php endif; ?>
<?php if ($_SESSION['user_data']['region'] != 'ISLAMABAD') : ?>
    <script>
        $url = "<?php echo ROOT_URL; ?>";
        location.replace($url+'Projects/');
    </script>
<?php endif; ?>
<?php endif; ?>
<?php if (!isset($_SESSION['is_logged_in'])) : ?>
    <script>
        $url = "<?php echo ROOT_URL; ?>";
        location.replace($url + 'users/login');
    </script>
<?php endif; ?>