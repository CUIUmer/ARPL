<?php if (isset($_SESSION['is_logged_in'])) : ?>
<div class="col-sm-12">
    <div class="card">
        <div class="card-header">
            <strong class="card-title">Activity List</strong>
        </div>
        <div class="card-body">
            <table id="bootstrap-data-table" class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Region</th>
                    <th>Created By</th>
                    <th>Creation Date</th>
                    <th>File</th>
                </tr>
                </thead>
                <tbody>
                <!--                    ADMIN-->
                <?php if ($_SESSION['user_data']['region'] == 'ISLAMABAD') : ?>
                    <?php foreach ($viewmodel as $item) : ?>
                        <?php $dt = new DateTime($item['cd']); ?>
                        <tr>
                            <td><?php echo $item['an']; ?></td>
                            <td><?php echo $item['ad']; ?></td>
                            <td><?php echo $item['ar']; ?></td>
                            <td><?php echo $item['cb']; ?></td>
                            <td><?php echo($dt->format('d/M/Y-D')); ?></td>
                            <td><a href="<?php echo ROOT_URL . $item['f']; ?>">Open</a></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>

                <!--                    Else-->
                <?php foreach ($viewmodel as $item) : ?>
                    <?php $dt = new DateTime($item['cd']); ?>
                    <?php if ($_SESSION['user_data']['region'] == $item['ar']) : ?>
                        <tr>
                            <td><?php echo $item['an']; ?></td>
                            <td><?php echo $item['ad']; ?></td>
                            <td><?php echo $item['ar']; ?></td>
                            <td><?php echo $item['cb']; ?></td>
                            <td><?php echo($dt->format('d/M/Y-D')); ?></td>
                            <td><a href="<?php echo ROOT_URL . $item['f']; ?>">Open</a></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>
<?php if (!isset($_SESSION['is_logged_in'])) : ?>
    <script>
        $url = "<?php echo ROOT_URL; ?>";
        location.replace($url + 'users/login');
    </script>
<?php endif; ?>