<?php if (isset($_SESSION['is_logged_in'])) : ?>
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <strong class="card-title">Project List</strong>
            </div>
            <div class="card-body">
                <table id="bootstrap-data-table" class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Regions</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($viewmodel as $item) : ?>
                            <tr>
                                <td><?php echo $item['name']; ?></td>
                                <td><?php echo $item['description']; ?></td>
                                <td><?php echo $item['startDate']; ?></td>
                                <td><?php echo $item['endDate']; ?></td>
                                <td><?php echo $item['region']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php if (!isset($_SESSION['is_logged_in'])) : ?>
    <script>
        $url = "<?php echo ROOT_URL; ?>";
        location.replace($url+'users/login');
    </script>
<?php endif; ?>
