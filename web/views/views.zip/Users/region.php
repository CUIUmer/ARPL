<?php if (isset($_SESSION['is_logged_in'])) : ?>
<div class="col-sm-12">
    <div class="card">
        <div class="card-header">
            <strong class="card-title">Region List</strong>
        </div>
        <div class="card-body">
            <table id="bootstrap-data-table" class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>Project Name</th>
                    <th>Region</th>
                    <th>User</th>
                    <th>Email</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                </tr>
                </thead>
                <tbody>
                <!--                    ADMIN-->
                <?php if ($_SESSION['user_data']['region'] == 'ISLAMABAD') : ?>
                    <?php foreach ($viewmodel as $item) : ?>
                        <tr>
                            <td><?php echo $item['pn']; ?></td>
                            <td><?php echo $item['ur']; ?></td>
                            <td><?php echo $item['un']; ?></td>
                            <td><?php echo $item['ue']; ?></td>
                            <td><?php echo $item['sd']; ?></td>
                            <td><?php echo $item['ed']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>

                <!--                    Else-->
                <?php foreach ($viewmodel as $item) : ?>
                    <?php if ($_SESSION['user_data']['region'] == $item['ur']) : ?>
                        <tr>
                            <td><?php echo $item['pn']; ?></td>
                            <td><?php echo $item['ur']; ?></td>
                            <td><?php echo $item['un']; ?></td>
                            <td><?php echo $item['ue']; ?></td>
                            <td><?php echo $item['sd']; ?></td>
                            <td><?php echo $item['ed']; ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>
<?php if (!isset($_SESSION['is_logged_in'])) : ?>
        <script>
            $url = "<?php echo ROOT_URL; ?>";
            location.replace($url+'users/login');
        </script>
<?php endif; ?>